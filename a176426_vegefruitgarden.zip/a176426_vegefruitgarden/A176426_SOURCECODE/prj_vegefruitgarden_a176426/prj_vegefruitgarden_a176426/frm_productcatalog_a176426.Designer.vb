﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_productcatalog_a176426
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.ltl_catalog = New System.Windows.Forms.Label()
        Me.pic_products = New System.Windows.Forms.PictureBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.lst_id = New System.Windows.Forms.ListBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_categoryid = New System.Windows.Forms.TextBox()
        Me.txt_weight = New System.Windows.Forms.TextBox()
        Me.txt_supplierid = New System.Windows.Forms.TextBox()
        Me.txt_storage = New System.Windows.Forms.TextBox()
        Me.lbl_name = New System.Windows.Forms.Label()
        Me.lbl_id = New System.Windows.Forms.Label()
        Me.lbl_price = New System.Windows.Forms.Label()
        Me.lbl_categoryid = New System.Windows.Forms.Label()
        Me.lbl_weight = New System.Windows.Forms.Label()
        Me.lbl_supplierid = New System.Windows.Forms.Label()
        Me.lbl_storage = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.pic_products, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Transparent
        Me.lbl_title.Font = New System.Drawing.Font("Monotype Corsiva", 25.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(400, 32)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(317, 52)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "VegeFruit Garden"
        '
        'ltl_catalog
        '
        Me.ltl_catalog.AutoSize = True
        Me.ltl_catalog.BackColor = System.Drawing.Color.Transparent
        Me.ltl_catalog.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ltl_catalog.Location = New System.Drawing.Point(472, 84)
        Me.ltl_catalog.Name = "ltl_catalog"
        Me.ltl_catalog.Size = New System.Drawing.Size(170, 33)
        Me.ltl_catalog.TabIndex = 1
        Me.ltl_catalog.Text = "- CATALOG -"
        '
        'pic_products
        '
        Me.pic_products.BackColor = System.Drawing.SystemColors.Control
        Me.pic_products.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_products.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_products.Location = New System.Drawing.Point(62, 224)
        Me.pic_products.Name = "pic_products"
        Me.pic_products.Size = New System.Drawing.Size(290, 285)
        Me.pic_products.TabIndex = 2
        Me.pic_products.TabStop = False
        '
        'txt_name
        '
        Me.txt_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_name.Location = New System.Drawing.Point(409, 205)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(308, 24)
        Me.txt_name.TabIndex = 3
        '
        'txt_id
        '
        Me.txt_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_id.Location = New System.Drawing.Point(409, 283)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.Size = New System.Drawing.Size(128, 24)
        Me.txt_id.TabIndex = 4
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_back.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_back.Location = New System.Drawing.Point(41, 32)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(107, 29)
        Me.btn_back.TabIndex = 5
        Me.btn_back.Text = "BACK"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'lst_id
        '
        Me.lst_id.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lst_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_id.FormattingEnabled = True
        Me.lst_id.ItemHeight = 18
        Me.lst_id.Location = New System.Drawing.Point(827, 182)
        Me.lst_id.Name = "lst_id"
        Me.lst_id.Size = New System.Drawing.Size(198, 364)
        Me.lst_id.TabIndex = 6
        '
        'txt_price
        '
        Me.txt_price.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_price.Location = New System.Drawing.Point(589, 283)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(128, 24)
        Me.txt_price.TabIndex = 7
        '
        'txt_categoryid
        '
        Me.txt_categoryid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_categoryid.Location = New System.Drawing.Point(409, 364)
        Me.txt_categoryid.Name = "txt_categoryid"
        Me.txt_categoryid.Size = New System.Drawing.Size(128, 24)
        Me.txt_categoryid.TabIndex = 8
        '
        'txt_weight
        '
        Me.txt_weight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_weight.Location = New System.Drawing.Point(589, 364)
        Me.txt_weight.Name = "txt_weight"
        Me.txt_weight.Size = New System.Drawing.Size(128, 24)
        Me.txt_weight.TabIndex = 9
        '
        'txt_supplierid
        '
        Me.txt_supplierid.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_supplierid.Location = New System.Drawing.Point(409, 446)
        Me.txt_supplierid.Name = "txt_supplierid"
        Me.txt_supplierid.Size = New System.Drawing.Size(128, 24)
        Me.txt_supplierid.TabIndex = 10
        '
        'txt_storage
        '
        Me.txt_storage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_storage.Location = New System.Drawing.Point(409, 525)
        Me.txt_storage.Name = "txt_storage"
        Me.txt_storage.Size = New System.Drawing.Size(308, 24)
        Me.txt_storage.TabIndex = 11
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.BackColor = System.Drawing.Color.Transparent
        Me.lbl_name.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_name.Location = New System.Drawing.Point(405, 182)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(116, 19)
        Me.lbl_name.TabIndex = 12
        Me.lbl_name.Text = "Product Name :"
        '
        'lbl_id
        '
        Me.lbl_id.AutoSize = True
        Me.lbl_id.BackColor = System.Drawing.Color.Transparent
        Me.lbl_id.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_id.Location = New System.Drawing.Point(405, 261)
        Me.lbl_id.Name = "lbl_id"
        Me.lbl_id.Size = New System.Drawing.Size(93, 19)
        Me.lbl_id.TabIndex = 13
        Me.lbl_id.Text = "Product ID :"
        '
        'lbl_price
        '
        Me.lbl_price.AutoSize = True
        Me.lbl_price.BackColor = System.Drawing.Color.Transparent
        Me.lbl_price.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_price.Location = New System.Drawing.Point(585, 261)
        Me.lbl_price.Name = "lbl_price"
        Me.lbl_price.Size = New System.Drawing.Size(97, 19)
        Me.lbl_price.TabIndex = 14
        Me.lbl_price.Text = "Price (RM) :"
        '
        'lbl_categoryid
        '
        Me.lbl_categoryid.AutoSize = True
        Me.lbl_categoryid.BackColor = System.Drawing.Color.Transparent
        Me.lbl_categoryid.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_categoryid.Location = New System.Drawing.Point(405, 342)
        Me.lbl_categoryid.Name = "lbl_categoryid"
        Me.lbl_categoryid.Size = New System.Drawing.Size(101, 19)
        Me.lbl_categoryid.TabIndex = 15
        Me.lbl_categoryid.Text = "Category ID :"
        '
        'lbl_weight
        '
        Me.lbl_weight.AutoSize = True
        Me.lbl_weight.BackColor = System.Drawing.Color.Transparent
        Me.lbl_weight.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_weight.Location = New System.Drawing.Point(585, 342)
        Me.lbl_weight.Name = "lbl_weight"
        Me.lbl_weight.Size = New System.Drawing.Size(107, 19)
        Me.lbl_weight.TabIndex = 16
        Me.lbl_weight.Text = "Weight (KG) :"
        '
        'lbl_supplierid
        '
        Me.lbl_supplierid.AutoSize = True
        Me.lbl_supplierid.BackColor = System.Drawing.Color.Transparent
        Me.lbl_supplierid.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_supplierid.Location = New System.Drawing.Point(405, 424)
        Me.lbl_supplierid.Name = "lbl_supplierid"
        Me.lbl_supplierid.Size = New System.Drawing.Size(96, 19)
        Me.lbl_supplierid.TabIndex = 17
        Me.lbl_supplierid.Text = "Supplier ID :"
        '
        'lbl_storage
        '
        Me.lbl_storage.AutoSize = True
        Me.lbl_storage.BackColor = System.Drawing.Color.Transparent
        Me.lbl_storage.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_storage.Location = New System.Drawing.Point(405, 503)
        Me.lbl_storage.Name = "lbl_storage"
        Me.lbl_storage.Size = New System.Drawing.Size(74, 19)
        Me.lbl_storage.TabIndex = 18
        Me.lbl_storage.Text = "Storage : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(813, 549)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(229, 19)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Click to view a product's details."
        '
        'frm_productcatalog_a176426
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.prj_vegefruitgarden_a176426.My.Resources.Resources.background1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1121, 613)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_storage)
        Me.Controls.Add(Me.lbl_supplierid)
        Me.Controls.Add(Me.lbl_weight)
        Me.Controls.Add(Me.lbl_categoryid)
        Me.Controls.Add(Me.lbl_price)
        Me.Controls.Add(Me.lbl_id)
        Me.Controls.Add(Me.lbl_name)
        Me.Controls.Add(Me.txt_storage)
        Me.Controls.Add(Me.txt_supplierid)
        Me.Controls.Add(Me.txt_weight)
        Me.Controls.Add(Me.txt_categoryid)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.lst_id)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.txt_id)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.pic_products)
        Me.Controls.Add(Me.ltl_catalog)
        Me.Controls.Add(Me.lbl_title)
        Me.DoubleBuffered = True
        Me.MaximumSize = New System.Drawing.Size(1139, 660)
        Me.Name = "frm_productcatalog_a176426"
        Me.Text = "VegeFruit Garden - Product Catalog"
        CType(Me.pic_products, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents ltl_catalog As Label
    Friend WithEvents pic_products As PictureBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents txt_id As TextBox
    Friend WithEvents btn_back As Button
    Friend WithEvents lst_id As ListBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_categoryid As TextBox
    Friend WithEvents txt_weight As TextBox
    Friend WithEvents txt_supplierid As TextBox
    Friend WithEvents txt_storage As TextBox
    Friend WithEvents lbl_name As Label
    Friend WithEvents lbl_id As Label
    Friend WithEvents lbl_price As Label
    Friend WithEvents lbl_categoryid As Label
    Friend WithEvents lbl_weight As Label
    Friend WithEvents lbl_supplierid As Label
    Friend WithEvents lbl_storage As Label
    Friend WithEvents Label1 As Label
End Class
