﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_mainmenu_a176426
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.btn_products = New System.Windows.Forms.Button()
        Me.btn_staff = New System.Windows.Forms.Button()
        Me.btn_orders = New System.Windows.Forms.Button()
        Me.btn_customers = New System.Windows.Forms.Button()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_mainmenu = New System.Windows.Forms.Label()
        Me.btn_catalog = New System.Windows.Forms.Button()
        Me.btn_insertproducts = New System.Windows.Forms.Button()
        Me.btn_updateproducts = New System.Windows.Forms.Button()
        Me.btn_insertcustomers = New System.Windows.Forms.Button()
        Me.btn_updatecustomers = New System.Windows.Forms.Button()
        Me.btn_insertstaff = New System.Windows.Forms.Button()
        Me.btn_updatestaff = New System.Windows.Forms.Button()
        Me.btn_makeorders = New System.Windows.Forms.Button()
        Me.btn_vieworders = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_exit.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_exit.Location = New System.Drawing.Point(159, 504)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(123, 33)
        Me.btn_exit.TabIndex = 0
        Me.btn_exit.Text = "EXIT"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'btn_products
        '
        Me.btn_products.AutoSize = True
        Me.btn_products.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_products.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_products.Location = New System.Drawing.Point(672, 67)
        Me.btn_products.Name = "btn_products"
        Me.btn_products.Size = New System.Drawing.Size(142, 33)
        Me.btn_products.TabIndex = 1
        Me.btn_products.Text = "Product Details"
        Me.btn_products.UseVisualStyleBackColor = False
        '
        'btn_staff
        '
        Me.btn_staff.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_staff.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staff.Location = New System.Drawing.Point(672, 465)
        Me.btn_staff.Name = "btn_staff"
        Me.btn_staff.Size = New System.Drawing.Size(142, 33)
        Me.btn_staff.TabIndex = 2
        Me.btn_staff.Text = "Staff Details"
        Me.btn_staff.UseVisualStyleBackColor = False
        '
        'btn_orders
        '
        Me.btn_orders.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_orders.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_orders.Location = New System.Drawing.Point(659, 200)
        Me.btn_orders.Name = "btn_orders"
        Me.btn_orders.Size = New System.Drawing.Size(142, 33)
        Me.btn_orders.TabIndex = 3
        Me.btn_orders.Text = "Order Details"
        Me.btn_orders.UseVisualStyleBackColor = False
        '
        'btn_customers
        '
        Me.btn_customers.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_customers.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customers.Location = New System.Drawing.Point(659, 332)
        Me.btn_customers.Name = "btn_customers"
        Me.btn_customers.Size = New System.Drawing.Size(155, 33)
        Me.btn_customers.TabIndex = 4
        Me.btn_customers.Text = "Customer Details"
        Me.btn_customers.UseVisualStyleBackColor = False
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.BackColor = System.Drawing.Color.Transparent
        Me.lbl_title.Font = New System.Drawing.Font("Monotype Corsiva", 30.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(46, 144)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(362, 60)
        Me.lbl_title.TabIndex = 5
        Me.lbl_title.Text = "VegeFruit Garden"
        '
        'lbl_mainmenu
        '
        Me.lbl_mainmenu.AutoSize = True
        Me.lbl_mainmenu.BackColor = System.Drawing.Color.Transparent
        Me.lbl_mainmenu.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_mainmenu.ForeColor = System.Drawing.Color.White
        Me.lbl_mainmenu.Location = New System.Drawing.Point(114, 219)
        Me.lbl_mainmenu.Name = "lbl_mainmenu"
        Me.lbl_mainmenu.Size = New System.Drawing.Size(234, 35)
        Me.lbl_mainmenu.TabIndex = 6
        Me.lbl_mainmenu.Text = "- MAIN MENU -"
        '
        'btn_catalog
        '
        Me.btn_catalog.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_catalog.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_catalog.Location = New System.Drawing.Point(672, 106)
        Me.btn_catalog.Name = "btn_catalog"
        Me.btn_catalog.Size = New System.Drawing.Size(142, 30)
        Me.btn_catalog.TabIndex = 7
        Me.btn_catalog.Text = "Catalog"
        Me.btn_catalog.UseVisualStyleBackColor = False
        '
        'btn_insertproducts
        '
        Me.btn_insertproducts.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_insertproducts.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insertproducts.Location = New System.Drawing.Point(832, 67)
        Me.btn_insertproducts.Name = "btn_insertproducts"
        Me.btn_insertproducts.Size = New System.Drawing.Size(107, 33)
        Me.btn_insertproducts.TabIndex = 8
        Me.btn_insertproducts.Text = "Insert"
        Me.btn_insertproducts.UseVisualStyleBackColor = False
        '
        'btn_updateproducts
        '
        Me.btn_updateproducts.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_updateproducts.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updateproducts.Location = New System.Drawing.Point(832, 107)
        Me.btn_updateproducts.Name = "btn_updateproducts"
        Me.btn_updateproducts.Size = New System.Drawing.Size(107, 29)
        Me.btn_updateproducts.TabIndex = 9
        Me.btn_updateproducts.Text = "Update"
        Me.btn_updateproducts.UseVisualStyleBackColor = False
        '
        'btn_insertcustomers
        '
        Me.btn_insertcustomers.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_insertcustomers.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insertcustomers.Location = New System.Drawing.Point(832, 332)
        Me.btn_insertcustomers.Name = "btn_insertcustomers"
        Me.btn_insertcustomers.Size = New System.Drawing.Size(107, 33)
        Me.btn_insertcustomers.TabIndex = 10
        Me.btn_insertcustomers.Text = "Insert"
        Me.btn_insertcustomers.UseVisualStyleBackColor = False
        '
        'btn_updatecustomers
        '
        Me.btn_updatecustomers.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_updatecustomers.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updatecustomers.Location = New System.Drawing.Point(832, 371)
        Me.btn_updatecustomers.Name = "btn_updatecustomers"
        Me.btn_updatecustomers.Size = New System.Drawing.Size(107, 33)
        Me.btn_updatecustomers.TabIndex = 11
        Me.btn_updatecustomers.Text = "Update"
        Me.btn_updatecustomers.UseVisualStyleBackColor = False
        '
        'btn_insertstaff
        '
        Me.btn_insertstaff.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_insertstaff.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_insertstaff.Location = New System.Drawing.Point(832, 465)
        Me.btn_insertstaff.Name = "btn_insertstaff"
        Me.btn_insertstaff.Size = New System.Drawing.Size(107, 33)
        Me.btn_insertstaff.TabIndex = 12
        Me.btn_insertstaff.Text = "Insert"
        Me.btn_insertstaff.UseVisualStyleBackColor = False
        '
        'btn_updatestaff
        '
        Me.btn_updatestaff.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_updatestaff.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updatestaff.Location = New System.Drawing.Point(832, 504)
        Me.btn_updatestaff.Name = "btn_updatestaff"
        Me.btn_updatestaff.Size = New System.Drawing.Size(107, 33)
        Me.btn_updatestaff.TabIndex = 13
        Me.btn_updatestaff.Text = "Update"
        Me.btn_updatestaff.UseVisualStyleBackColor = False
        '
        'btn_makeorders
        '
        Me.btn_makeorders.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_makeorders.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_makeorders.Location = New System.Drawing.Point(814, 200)
        Me.btn_makeorders.Name = "btn_makeorders"
        Me.btn_makeorders.Size = New System.Drawing.Size(125, 33)
        Me.btn_makeorders.TabIndex = 14
        Me.btn_makeorders.Text = "Make Orders"
        Me.btn_makeorders.UseVisualStyleBackColor = False
        '
        'btn_vieworders
        '
        Me.btn_vieworders.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_vieworders.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_vieworders.Location = New System.Drawing.Point(814, 239)
        Me.btn_vieworders.Name = "btn_vieworders"
        Me.btn_vieworders.Size = New System.Drawing.Size(125, 33)
        Me.btn_vieworders.TabIndex = 15
        Me.btn_vieworders.Text = "View Orders"
        Me.btn_vieworders.UseVisualStyleBackColor = False
        '
        'frm_mainmenu_a176426
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = Global.prj_vegefruitgarden_a176426.My.Resources.Resources.mainmenu3
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(994, 566)
        Me.Controls.Add(Me.btn_vieworders)
        Me.Controls.Add(Me.btn_makeorders)
        Me.Controls.Add(Me.btn_updatestaff)
        Me.Controls.Add(Me.btn_insertstaff)
        Me.Controls.Add(Me.btn_updatecustomers)
        Me.Controls.Add(Me.btn_insertcustomers)
        Me.Controls.Add(Me.btn_updateproducts)
        Me.Controls.Add(Me.btn_insertproducts)
        Me.Controls.Add(Me.btn_catalog)
        Me.Controls.Add(Me.lbl_mainmenu)
        Me.Controls.Add(Me.lbl_title)
        Me.Controls.Add(Me.btn_customers)
        Me.Controls.Add(Me.btn_orders)
        Me.Controls.Add(Me.btn_staff)
        Me.Controls.Add(Me.btn_products)
        Me.Controls.Add(Me.btn_exit)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximumSize = New System.Drawing.Size(1016, 617)
        Me.Name = "frm_mainmenu_a176426"
        Me.Text = "VegeFruit Garden - Main Menu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_exit As Button
    Friend WithEvents btn_products As Button
    Friend WithEvents btn_staff As Button
    Friend WithEvents btn_orders As Button
    Friend WithEvents btn_customers As Button
    Friend WithEvents lbl_title As Label
    Friend WithEvents lbl_mainmenu As Label
    Friend WithEvents btn_catalog As Button
    Friend WithEvents btn_insertproducts As Button
    Friend WithEvents btn_updateproducts As Button
    Friend WithEvents btn_insertcustomers As Button
    Friend WithEvents btn_updatecustomers As Button
    Friend WithEvents btn_insertstaff As Button
    Friend WithEvents btn_updatestaff As Button
    Friend WithEvents btn_makeorders As Button
    Friend WithEvents btn_vieworders As Button
End Class
