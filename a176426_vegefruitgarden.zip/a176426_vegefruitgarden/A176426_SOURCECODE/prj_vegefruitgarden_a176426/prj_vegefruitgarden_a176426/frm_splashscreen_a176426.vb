﻿Public Class frm_splashscreen_a176426
    Private Sub frm_splashscreen_a176426_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_start_Click(sender As Object, e As EventArgs) Handles btn_start.Click
        frm_mainmenu_a176426.Show()
        Me.Hide()
    End Sub
End Class